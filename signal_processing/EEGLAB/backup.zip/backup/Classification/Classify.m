% tells you whether theres a seizure from input data per epoch

function [EpochSeizures] = Classify(model, input_epoch)


end