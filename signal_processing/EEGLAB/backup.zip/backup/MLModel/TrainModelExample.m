dataset = 'chb04';
path = "C:\Users\Arthur\Desktop\Programming\BCIBAP\signal_processing\EEGLAB\sample_data\" + dataset + "\";
nFiles = 5;
TrainModel(dataset, path, nFiles);